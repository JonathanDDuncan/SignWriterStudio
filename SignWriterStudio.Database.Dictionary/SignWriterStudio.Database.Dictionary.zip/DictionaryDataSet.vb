﻿

Partial Public Class DictionaryDataSet
End Class
